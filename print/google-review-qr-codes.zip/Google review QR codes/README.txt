Chudleigh Health Hub - Google review QR code
=============================================

Every file here links to your Google review form:
https://g.page/r/CVpV558Bn1AiEBM/review

Review card A6.pdf   Print this one. A6 card (105 x 148 mm). Choose A6 paper,
                     or print on A4 at "actual size" and trim.
Review card A6.png   Same card as a picture, for social media, emails or texts.
Review card A6.svg   Same card in a format print shops can scale to any size.
QR code.png          Just the QR code, for posters, appointment cards or slides.
QR code.svg          Just the QR code, scalable to any size without blurring.

Tip: hand the card to patients when they say they feel better, and reply to
every review on Google.
